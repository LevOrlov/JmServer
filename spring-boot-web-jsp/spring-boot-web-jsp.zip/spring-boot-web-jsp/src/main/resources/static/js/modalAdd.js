// Get the modal


// Get the button that opens the modal
var btn3 = document.getElementById("elementAdd");
// Get the <span> element that closes the modal
var btn4 = document.getElementById("buttoncloseAdd");
var btn31 = document.getElementById("user");
var btn43 = document.getElementById("pass1");
var btn44 = document.getElementById("AddModal");

// When the user clicks the button, open the modal
btn3.onclick = function() {
    $("#AddModal").css("display", "block");
}
// When the user clicks on <span> (x), close the modal
btn4.onclick = function() {
    $("#AddModal").css("display", "none");
}